package com.example.thirdassignment;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MyInterface {
    @GET("books/v1/volumes?q=isbn:")
    Call<String> value();
}
