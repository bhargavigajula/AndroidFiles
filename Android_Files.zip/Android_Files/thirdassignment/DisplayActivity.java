package com.example.thirdassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DisplayActivity extends AppCompatActivity {
    ImageView iv;
    TextView id,title,pub;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        iv = findViewById(R.id.imageView);
        id = findViewById(R.id.id);
        title = findViewById(R.id.title);
        pub = findViewById(R.id.pub);
        Picasso.with(this).load(getIntent().getStringExtra("link")).into(iv);
        title.setText("Title : "+getIntent().getStringExtra("title"));
        id.setText("Book ID : "+getIntent().getStringExtra("id"));
        pub.setText("Published Date : "+getIntent().getStringExtra("pub"));

    }
}