package com.example.thirdassignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class MainActivity extends AppCompatActivity {
    RecyclerView rv;
    Retrofit retrofit;
    MyInterface myInterface;
    ArrayList<Pojo> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.rv);
        list = new ArrayList<>();
        retrofit = new Retrofit.Builder().baseUrl("https://www.googleapis.com/").
                addConverterFactory(ScalarsConverterFactory.create()).build();
        myInterface = retrofit.create(MyInterface.class);
        Call<String> response = myInterface.value();
        response.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Toast.makeText(MainActivity.this,
                        ""+response.body(), Toast.LENGTH_SHORT).show();
                String r = response.body();
                try {
                    JSONObject root = new JSONObject(r);
                    JSONArray items = root.getJSONArray("items");
                    for (int i = 0;i < items.length();i++){
                        JSONObject object = items.getJSONObject(i);
                        String id = object.getString("id");
                        JSONObject volume = object.getJSONObject("volumeInfo");
                        String title = volume.getString("title");
                        String pub = volume.getString("publishedDate");
                        JSONObject images = volume.getJSONObject("imageLinks");
                        String link = images.getString("smallThumbnail");
                        Pojo pojo = new Pojo(id,title,pub,link);
                        list.add(pojo);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                MyAdapter adapter = new MyAdapter(MainActivity.this,list);
                rv.setAdapter(adapter);
                rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Fail to fetch!!!", Toast.LENGTH_SHORT).show();
            }

        });

    }
}