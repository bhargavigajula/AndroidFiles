package com.example.newsecondassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity2 extends AppCompatActivity {
    EditText ed1,ed2;
    Button btn;
    FirebaseAuth fa;
    private FirebaseAuth.AuthStateListener asl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        fa = FirebaseAuth.getInstance();
        ed1 = findViewById(R.id.email);
        ed2 = findViewById(R.id.pass);
        btn = findViewById(R.id.btn);
        asl = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = fa.getCurrentUser();
                if(mFirebaseUser != null) {
                    Toast.makeText(MainActivity2.this, "Your are logged in !!!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity2.this, MainActivity3.class));
                }
                else {
                    Toast.makeText(MainActivity2.this, "Please login again!!!", Toast.LENGTH_SHORT).show();
                }
            }
        };
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = ed1.getText().toString();
                String pass = ed2.getText().toString();
                if(email.isEmpty() || pass.isEmpty())
                    Toast.makeText(MainActivity2.this, "Please enter All fields!!!", Toast.LENGTH_SHORT).show();
                else {
                    fa.signInWithEmailAndPassword(email,pass).addOnCompleteListener(MainActivity2.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity2.this, "You Logged in !!!", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(MainActivity2.this, MainActivity3.class));
                            } else
                                Toast.makeText(MainActivity2.this, "Your login is Failed!!!please try Again", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
    public void singup(View view) {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
    }

}