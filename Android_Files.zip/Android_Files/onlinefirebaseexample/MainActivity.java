package com.example.onlinefirebaseexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    EditText name,roll,number;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        roll = findViewById(R.id.roll);
        number = findViewById(R.id.number);
        reference  = FirebaseDatabase.getInstance().getReference("Data");

    }

    public void save(View view) {
        String sname = name.getText().toString();
        String sroll = roll.getText().toString();
        String snum = number.getText().toString();
        MyModel myModel = new MyModel(sname,sroll,snum);
        /// String id = reference.push().getKey();
        reference.child(sroll).setValue(myModel);
        Toast.makeText(this, "Data Inserted",
                Toast.LENGTH_SHORT).show();
    }

    public void data(View view) {
    }
}