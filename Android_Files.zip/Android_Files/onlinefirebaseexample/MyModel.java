package com.example.onlinefirebaseexample;

public class MyModel {
    String sname,sroll,snum;

    public MyModel(String sname, String sroll, String snum) {
        this.sname = sname;
        this.sroll = sroll;
        this.snum = snum;
    }
    public MyModel() {

    }
    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSroll() {
        return sroll;
    }

    public void setSroll(String sroll) {
        this.sroll = sroll;
    }

    public String getSnum() {
        return snum;
    }

    public void setSnum(String snum) {
        this.snum = snum;
    }
}
