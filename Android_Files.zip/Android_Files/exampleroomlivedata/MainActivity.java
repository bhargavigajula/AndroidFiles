package com.example.exampleroomlivedata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.exampleroomlivedata.Rdatabase.MyViewModel;
import com.example.exampleroomlivedata.Rdatabase.RDatabase;
import com.example.exampleroomlivedata.Rdatabase.Rtable;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText name,roll,number,e;
    public static MyViewModel viewModel;
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        roll = findViewById(R.id.roll);
        number = findViewById(R.id.number);
        e = findViewById(R.id.email);
        rv = findViewById(R.id.rv);
        viewModel = new ViewModelProvider(this).get(MyViewModel.class);
        viewModel.readData().observe(this, new Observer<List<Rtable>>() {
            @Override
            public void onChanged(List<Rtable> rtables) {
                MyAdapter adapter = new MyAdapter(MainActivity.this, rtables);
                rv.setAdapter(adapter);
                rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            }
        });
    }

    public void submit(View view) {
        String n = name.getText().toString();
        String r = roll.getText().toString();
        String num = number.getText().toString();
        String em = e.getText().toString();
        Rtable rtable = new Rtable();
        rtable.setName(n);
        rtable.setRoll(r);
        rtable.setNumber(num);
        rtable.setEmail(em);
        viewModel.insert(rtable);
        Toast.makeText(this, "Successfully saved", Toast.LENGTH_SHORT).show();
    }
}