package com.example.secondassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity2 extends AppCompatActivity {
    EditText ed1,ed2;
    FirebaseAuth fa;
    FirebaseUser fu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        fa = FirebaseAuth.getInstance();
        fu = fa.getCurrentUser();
        ed1 = findViewById(R.id.email);
        ed2 = findViewById(R.id.pass);
    }

    public void singin(View view) {
        String email = ed1.getText().toString();
        String pass = ed2.getText().toString();
        if(email.isEmpty() | pass.isEmpty())
            Toast.makeText(this, "Please enter All fields!!!", Toast.LENGTH_SHORT).show();
        else {
            fa.signInWithEmailAndPassword(email,pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(MainActivity2.this, "You Logged in !!!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity2.this, MainActivity3.class));
                    } else
                        Toast.makeText(MainActivity2.this, "Your login is Failed!!!please try Again", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void set(View view) {
        Intent i = new Intent(MainActivity2.this,MainActivity4.class);
        startActivity(i);
    }
    public void singup(View view) {
        Intent i = new Intent(MainActivity2.this,MainActivity.class);
        startActivity(i);
    }

}