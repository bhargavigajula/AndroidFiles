package com.example.secondassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2;
    FirebaseAuth fa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fa = FirebaseAuth.getInstance();
        ed1 = findViewById(R.id.email);
        ed2 = findViewById(R.id.pass);
    }

    public void singup(View view) {
         String email = ed1.getText().toString();
         String pass = ed2.getText().toString();
         if(email.isEmpty() | pass.isEmpty())
             Toast.makeText(this, "Please enter All fields!!!", Toast.LENGTH_SHORT).show();
         else {
             fa.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                 @Override
                 public void onComplete(@NonNull Task<AuthResult> task) {
                     if (task.isComplete()) {
                         Toast.makeText(MainActivity.this, "Your Registration is Successfull!!!", Toast.LENGTH_SHORT).show();
                         Intent i =  new Intent(MainActivity.this, MainActivity3.class);
                         startActivity(i);
                     } else {
                         Toast.makeText(MainActivity.this, "Your Registration is Failed!!!please try Again", Toast.LENGTH_SHORT).show();
                     }
                 }
             });
         }
    }

    public void singin(View view) {
        Intent i = new Intent(MainActivity.this,MainActivity2.class);
        startActivity(i);
    }
}