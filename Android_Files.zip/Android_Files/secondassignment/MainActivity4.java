package com.example.secondassignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity4 extends AppCompatActivity {
    EditText ev;
    FirebaseAuth fa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        fa = FirebaseAuth.getInstance();
        ev = findViewById(R.id.email);
    }

    public void reset(View view) {
        String email = ev.getText().toString();
        fa.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isComplete()) {
                    Toast.makeText(MainActivity4.this, "Link is Send to your mail", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity4.this, "failed to send", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void back(View view) {
        startActivity(new Intent(this,MainActivity2.class));
    }
}