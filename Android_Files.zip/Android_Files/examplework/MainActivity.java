package com.example.examplework;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import android.os.Bundle;
import android.view.View;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    OneTimeWorkRequest sv,sv1;
    PeriodicWorkRequest pw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Constraints c = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        sv = new OneTimeWorkRequest.Builder(FirstWork.class).build();
        sv1 = new OneTimeWorkRequest.Builder(SecondWorker.class).setInitialDelay(5, TimeUnit.SECONDS).build();
        pw = new PeriodicWorkRequest.Builder(ThirdWork.class,15,TimeUnit.SECONDS).build();
    }
    public void doWork(View view) {
        WorkManager.getInstance(this).enqueue(pw);
        WorkManager.getInstance(this).beginWith(sv1).then(sv).enqueue();
        //WorkManager.getInstance(this).enqueue(sv1);
    }
}