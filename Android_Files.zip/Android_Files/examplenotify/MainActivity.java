package com.example.examplenotify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    NotificationManager nm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    public void notify(View view) {
        createNotification();
        sendNotification();
    }

    private void sendNotification() {
        NotificationCompat.Builder b = new NotificationCompat.Builder(this,"demo");
        Intent i = new Intent(this,MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT);
        b.setContentTitle("Notification");
        b.setContentText("This is my Notification");
        b.setSmallIcon(R.drawable.ic_launcher_background);
        b.setDefaults(NotificationCompat.DEFAULT_ALL);
        b.setContentIntent(pi);
        b.setAutoCancel(true);
        b.addAction(R.drawable.ic_launcher_background,"Reply",pi);
        nm.notify(0,b.build());
    }

    private void createNotification() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel("demo","bharu",NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ch.enableLights(true);
            ch.setLightColor(android.R.color.holo_red_light);
            nm.createNotificationChannel(ch);
        }
    }
}