package com.example.firstexperiment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Log.i("vasu","Create");
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.i("vasu","start");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("vasu","Resume");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("vasu","stop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("vasu","Pause");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("vasu","Restart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("vasu","Destroy");
    }

}