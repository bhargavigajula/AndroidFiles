package com.example.sharedpreferexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.user);
        e2 = findViewById(R.id.pass);
        sp = getSharedPreferences("Data",MODE_PRIVATE);
    }

    public void login(View view) {
        String n = e1.getText().toString();
        String p = e2.getText().toString();
        SharedPreferences.Editor ed = sp.edit();
        ed.putString("name",n);
        ed.putString("pass",p);
        ed.commit();
        Intent i = new Intent(this,MainActivity2.class);
        startActivity(i);
    }
}