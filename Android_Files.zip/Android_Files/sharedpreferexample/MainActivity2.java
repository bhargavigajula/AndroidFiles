package com.example.sharedpreferexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    SharedPreferences sp;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
         tv = findViewById(R.id.tv);
        sp = getSharedPreferences("Data",MODE_PRIVATE);
        String name = sp.getString("name",null);
        String pass = sp.getString("pass",null);
        tv.setText("Welcome to "+name+"!!!!\nYour Password "+pass);
    }
}