package com.example.firstassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText uname,upass;
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        uname = findViewById(R.id.uname);
        upass = findViewById(R.id.upass);
    }
    public void login(View view) {
        String name1 = uname.getText().toString();
        String pass1 = upass.getText().toString();
        /*preferences = getSharedPreferences("Data",MODE_PRIVATE);
        //To fetch the data from sharedprefernces
        String n = preferences.getString("name",null);
        String p = preferences.getString("pass",null);*/
        String n = getIntent().getStringExtra("name");
        String p = getIntent().getStringExtra("password");
        if (n.equals(name1) & p.equals(pass1)) {
            Intent i = new Intent(this,MainActivity3.class);
            i.putExtra("name",n);
            startActivity(i);
        }
        else {
            Toast.makeText(this, "Please Enter Valid Credentials!!!", Toast.LENGTH_SHORT).show();
        }
    }
}