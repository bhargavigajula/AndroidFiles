package com.example.firstassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText uname,password;
    //SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uname = findViewById(R.id.uname);
        password = findViewById(R.id.password);
    }
    public void register(View view) {
        String name = uname.getText().toString();
        String pass = password.getText().toString();
       /* preferences = getSharedPreferences("Data",MODE_PRIVATE);
        //To push the data into sharedpreferences
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("name",name);
        editor.putString("pass",pass);
        editor.commit();
        Intent i = new Intent(this,MainActivity2.class);
        startActivity(i);*/
       Intent i = new Intent(this,MainActivity2.class);
       i.putExtra("name",name);
       i.putExtra("password",pass);
       startActivity(i);
    }
}